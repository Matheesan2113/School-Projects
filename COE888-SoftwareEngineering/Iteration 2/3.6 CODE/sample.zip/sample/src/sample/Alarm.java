/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.*;

/**
 *
 * @author matheesan
 */
public class Alarm {

    boolean check;
    long b;
    Timer timer;
    TimerTask task, task2;
    Notification h;

    Alarm(long a) {
        b = a;
        AlarmRun(b);
    }

    public boolean AlarmDone() {
        boolean done = false;
        if (b <= 0) 
            done = true;
        return done;
    }
    public void AlarmRun(long l) {
        b = l;
        this.timer = new Timer();
        this.task = new TimerTask() {
            public void run() {
                b--;
            }
        };
        timer.scheduleAtFixedRate(task, 0, 1);
    }
    public void setB(long b) {
        this.b = b;
    }
    public long getB() {
        return b;
    }
    @Override
    public String toString() {
        return ("");
    }
}
