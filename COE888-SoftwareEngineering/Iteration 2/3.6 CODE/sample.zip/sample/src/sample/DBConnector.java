/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author matheesan
 */
public class DBConnector {
    //FIRST INITIALIZE THESE VARIABLES

    Connection myConn = null;
    Statement myStmt = null;
    ResultSet myrs = null;
    PreparedStatement ps = null;

    public DBConnector() {
        //WHENEVER YOU MESS WITH SQL, IT GOES IN A TRY CATCH BLOCK AND YOU MUST INITIALIZE VALUES
        try {
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?useSSL=false", "root", "mathee25");
            myStmt = myConn.createStatement();
            //YOU CAN HAVE AN UPDATE STATEMENT ONLY IF you CHANGE QUERY TO UPDATE IN METHOD CALL
            //  myStmt.executeUpdate("INSERT INTO loginwop (username, password) VALUES ('OG','polka')");
            //INITIALIZE AS IS ONLY IF ITS QUERY
            myrs = myStmt.executeQuery("select * from loginwop");
            //WHILE LOOP TO ITERATE THROUGH ARRAY
            while (myrs.next()) {
                //System.out.println(myrs.findColumn("username") +" , "+ myrs.getString("username"));
            }
            // myStmt.executeUpdate("DELETE FROM loginwop WHERE (password='polka')");
            //END TRY CATCH
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }

    public ArrayList<WorkOP> startupWorkOP() {
        ArrayList<WorkOP> workOPList = new ArrayList<WorkOP>();
        try {
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?useSSL=false", "root", "mathee25");
            myStmt = myConn.createStatement();
            //INITIALIZE AS IS ONLY IF ITS QUERY
            myrs = myStmt.executeQuery("select * from loginwop");
            while (myrs.next()) {
                workOPList.add(new WorkOP(myrs.getString("Username"), myrs.getString("Password")));
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return (workOPList);
    }

    public ArrayList<ProcessEngineer> startupEngineer() {
        ArrayList<ProcessEngineer> workOPList = new ArrayList<ProcessEngineer>();
        try {
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?useSSL=false", "root", "mathee25");
            myStmt = myConn.createStatement();
            //INITIALIZE AS IS ONLY IF ITS QUERY
            myrs = myStmt.executeQuery("select * from loginEngineer");
            while (myrs.next()) {
                workOPList.add(new ProcessEngineer(myrs.getString("Username"), myrs.getString("Password")));
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return (workOPList);
    }

    public ArrayList<ProductManager> startupManager() {
        ArrayList<ProductManager> workOPList = new ArrayList<ProductManager>();
        try {
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?useSSL=false", "root", "mathee25");
            myStmt = myConn.createStatement();
            //INITIALIZE AS IS ONLY IF ITS QUERY
            myrs = myStmt.executeQuery("select * from loginManager");
            while (myrs.next()) {
                workOPList.add(new ProductManager(myrs.getString("Username"), myrs.getString("Password")));
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return (workOPList);
    }

    public void addLoginuser(String loginuser, String loginpword, int a) {
        try {
            switch (a) {
                case 1:
                    //THIS MAY NEED TO BE FIXED WHEN ADDING FIELDS TO WORKSTATION OPERATOR
                    //
                    //
                    //
                    ps = myConn.prepareStatement("INSERT INTO loginwop (username,password) VALUES (?,?)");
                    break;
                case 2:
                    ps = myConn.prepareStatement("INSERT INTO loginEngineer (username,password) VALUES (?,?)");
                    break;
                case 3:
                    ps = myConn.prepareStatement("INSERT INTO loginManager (username,password) VALUES (?,?)");
                    break;
            }
            ps.setString(1, loginuser);
            ps.setString(2, loginpword);
            ps.execute();
        } catch (Exception ex) {

        }
    }

    public boolean authenticate(String loginuser, String loginpword, int a) {
        boolean authenticate = false;
        try {
            switch (a) {
                case 1:
                    myrs = myStmt.executeQuery("select * from loginwop");
                    break;
                case 2:
                    myrs = myStmt.executeQuery("select * from loginEngineer");
                    break;
                case 3:
                    myrs = myStmt.executeQuery("select * from loginManager");
                    break;
            }
            while (myrs.next()) {
                if (myrs.getString("username").equals(loginuser)) {
                    if (myrs.getString("password").equals(loginpword)) {
                        authenticate = true;
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println("Something happened in dbconnection class, method: authenticate");
        }
        return authenticate;
    }

    public void deleteloginWOP(String deleteloginwop) {
        try {
            PreparedStatement ps = myConn.prepareStatement("DELETE FROM loginwop WHERE username = ?");
            ps.setString(1, deleteloginwop);
            ps.execute();
        } catch (Exception ex) {

        }
    }

    public void updateloginWOP(String update1loginwop, String update2loginwop,String uname, String uname2) {
        try {
            PreparedStatement ps = myConn.prepareStatement("UPDATE loginwop SET id = id + 1 WHERE username = ? ");
            ps.setString(1, uname);
            ps.executeUpdate();           
            PreparedStatement ps2 = myConn.prepareStatement("INSERT INTO table1 (id, value) VALUES ("+uname+", 300)");
            //PreparedStatement ps = myConn.prepareStatement("DELETE FROM loginwop WHERE username = ?");           
            ps.execute();
        } catch (Exception ex) {

        }
    }
}
