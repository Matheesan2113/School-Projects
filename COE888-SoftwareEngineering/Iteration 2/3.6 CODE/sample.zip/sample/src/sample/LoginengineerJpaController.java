/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import sample.exceptions.NonexistentEntityException;

/**
 *
 * @author matheesan
 */
public class LoginengineerJpaController implements Serializable {

    public LoginengineerJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Loginengineer loginengineer) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(loginengineer);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Loginengineer loginengineer) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            loginengineer = em.merge(loginengineer);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = loginengineer.getId();
                if (findLoginengineer(id) == null) {
                    throw new NonexistentEntityException("The loginengineer with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Loginengineer loginengineer;
            try {
                loginengineer = em.getReference(Loginengineer.class, id);
                loginengineer.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The loginengineer with id " + id + " no longer exists.", enfe);
            }
            em.remove(loginengineer);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Loginengineer> findLoginengineerEntities() {
        return findLoginengineerEntities(true, -1, -1);
    }

    public List<Loginengineer> findLoginengineerEntities(int maxResults, int firstResult) {
        return findLoginengineerEntities(false, maxResults, firstResult);
    }

    private List<Loginengineer> findLoginengineerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Loginengineer.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Loginengineer findLoginengineer(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Loginengineer.class, id);
        } finally {
            em.close();
        }
    }

    public int getLoginengineerCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Loginengineer> rt = cq.from(Loginengineer.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
