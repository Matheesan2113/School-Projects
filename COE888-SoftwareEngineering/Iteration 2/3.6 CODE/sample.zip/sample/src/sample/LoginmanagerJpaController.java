/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import sample.exceptions.NonexistentEntityException;

/**
 *
 * @author matheesan
 */
public class LoginmanagerJpaController implements Serializable {

    public LoginmanagerJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Loginmanager loginmanager) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(loginmanager);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Loginmanager loginmanager) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            loginmanager = em.merge(loginmanager);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = loginmanager.getId();
                if (findLoginmanager(id) == null) {
                    throw new NonexistentEntityException("The loginmanager with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Loginmanager loginmanager;
            try {
                loginmanager = em.getReference(Loginmanager.class, id);
                loginmanager.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The loginmanager with id " + id + " no longer exists.", enfe);
            }
            em.remove(loginmanager);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Loginmanager> findLoginmanagerEntities() {
        return findLoginmanagerEntities(true, -1, -1);
    }

    public List<Loginmanager> findLoginmanagerEntities(int maxResults, int firstResult) {
        return findLoginmanagerEntities(false, maxResults, firstResult);
    }

    private List<Loginmanager> findLoginmanagerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Loginmanager.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Loginmanager findLoginmanager(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Loginmanager.class, id);
        } finally {
            em.close();
        }
    }

    public int getLoginmanagerCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Loginmanager> rt = cq.from(Loginmanager.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
