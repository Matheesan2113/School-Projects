/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import sample.exceptions.NonexistentEntityException;

/**
 *
 * @author matheesan
 */
public class LoginwopJpaController implements Serializable {

    public LoginwopJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Loginwop loginwop) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Workstations workstation = loginwop.getWorkstation();
            if (workstation != null) {
                workstation = em.getReference(workstation.getClass(), workstation.getId());
                loginwop.setWorkstation(workstation);
            }
            em.persist(loginwop);
            if (workstation != null) {
                workstation.getLoginwopCollection().add(loginwop);
                workstation = em.merge(workstation);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Loginwop loginwop) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Loginwop persistentLoginwop = em.find(Loginwop.class, loginwop.getId());
            Workstations workstationOld = persistentLoginwop.getWorkstation();
            Workstations workstationNew = loginwop.getWorkstation();
            if (workstationNew != null) {
                workstationNew = em.getReference(workstationNew.getClass(), workstationNew.getId());
                loginwop.setWorkstation(workstationNew);
            }
            loginwop = em.merge(loginwop);
            if (workstationOld != null && !workstationOld.equals(workstationNew)) {
                workstationOld.getLoginwopCollection().remove(loginwop);
                workstationOld = em.merge(workstationOld);
            }
            if (workstationNew != null && !workstationNew.equals(workstationOld)) {
                workstationNew.getLoginwopCollection().add(loginwop);
                workstationNew = em.merge(workstationNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = loginwop.getId();
                if (findLoginwop(id) == null) {
                    throw new NonexistentEntityException("The loginwop with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Loginwop loginwop;
            try {
                loginwop = em.getReference(Loginwop.class, id);
                loginwop.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The loginwop with id " + id + " no longer exists.", enfe);
            }
            Workstations workstation = loginwop.getWorkstation();
            if (workstation != null) {
                workstation.getLoginwopCollection().remove(loginwop);
                workstation = em.merge(workstation);
            }
            em.remove(loginwop);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Loginwop> findLoginwopEntities() {
        return findLoginwopEntities(true, -1, -1);
    }

    public List<Loginwop> findLoginwopEntities(int maxResults, int firstResult) {
        return findLoginwopEntities(false, maxResults, firstResult);
    }

    private List<Loginwop> findLoginwopEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Loginwop.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Loginwop findLoginwop(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Loginwop.class, id);
        } finally {
            em.close();
        }
    }

    public int getLoginwopCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Loginwop> rt = cq.from(Loginwop.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
