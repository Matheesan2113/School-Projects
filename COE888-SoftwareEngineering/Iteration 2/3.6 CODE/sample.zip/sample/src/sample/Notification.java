/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author matheesan
 */
public class Notification {
    long a=0;
    boolean ring=false;
    Alarm alarm;
    Notification(Alarm alarm){
        this.alarm=alarm;
        a=alarm.getB();
    }
    public boolean Notify(){
       if(alarm.AlarmDone()==true)
                 ring=true;   
        return ring;
    }
}

