/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.*;

/**
 *
 * @author matheesan
 */
public class ProcessEngineer extends User {

    ArrayList<WorkOP> workarray = new ArrayList<WorkOP>();
    DBConnector a;

    public ProcessEngineer(String uname, String pword) {
        super();
        this.Uname = uname;
        this.Pword = pword;
        //a=new DBConnector();
    }
    public ArrayList<WorkOP> createworkop(String uname, String pword, ArrayList<WorkOP> workop, DBConnector a) {
        workop.add(new WorkOP(uname, pword));
        a.addLoginuser(uname, pword, 1);
        System.out.println(workop);
        return workop;
    }

    public ArrayList<WorkOP> deleteworkop(String uname, ArrayList<WorkOP> workop, DBConnector a) {
        a.deleteloginWOP(uname);
        for (int y = 0; y < workop.size(); y++) {
            if (workop.get(y).getUname().equalsIgnoreCase(uname)) {
                workop.remove(y);
            }
        }
        return workop;
    }

    public ArrayList<WorkOP> UpdateworkOP(String uname, String uname2, ArrayList<WorkOP> workop) {
        WorkOP temp, temp2;
        for (int r = 0; r < workop.size(); r++) {
            if (workop.get(r).getUname().equalsIgnoreCase(uname2)) {
                temp = workop.get(r + 1);
                for (int q = 0; q < workop.size(); q++) {
                    System.out.println(workop.get(q).getUname() + uname);
                    if (workop.get(q).getUname().equalsIgnoreCase(uname)) {
                        temp2 = workop.get(q);
                        workop.add(r + 1, temp2);
                        workop.remove(q + 1);
                    } else {
                        System.out.println("user2 not found");
                    }
                }
            } else {
                System.out.println("user1 not found");
            }
        }
        System.out.println(workop);
        return workop;
    }
}
