/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author matheesan
 */
public class ProductManager extends User {
    String message;
    public ProductManager(String uname,String pword) {
        super();
        this.Uname=uname;
        this.Pword=pword;
    }
    public void setMessage(String message){
        this.message=message;
    }
    public String getMessage(){
        return message;
    }
}
