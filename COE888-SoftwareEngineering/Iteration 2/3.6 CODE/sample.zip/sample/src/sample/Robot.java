/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author matheesan
 */
public abstract class Robot {
private Alarm a;
Notification b;
    /**
     * @return the a
     */
    public Alarm getAlarm() {
        return a;
    }
    Robot (long alarm){
        a = new Alarm(alarm);
        //a.AlarmRun(alarm);
    }
    public boolean getNotification(){
        boolean check;
       if(a.AlarmDone()==true)
        check= true;
        else
        check= false;
        return check;
    }
}
