/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author matheesan
 */
public class User {
    
    protected String Uname;
    protected String Pword;
    protected int id;

    public User() {
    }

    /**
     * @return the Uname
     */
    public String getUname() {
        return Uname;
    }

    /**
     * @return the Pword
     */
    public String getPword() {
        return Pword;
    }

    /**
     * @param Pword the Pword to set
     */
    public void setPword(String Pword) {
        this.Pword = Pword;
    }

        public void setUname(String uname) {
        this.Uname = uname;
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
    public String toString(){
        return (this.getUname());
    }
    
}
