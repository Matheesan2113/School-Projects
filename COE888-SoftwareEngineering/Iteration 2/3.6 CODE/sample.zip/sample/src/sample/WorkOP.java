/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author matheesan
 */
class WorkOP extends User {

    private String Uname;
    private String Pword;
    private int id;
    private Workstation a;

    /**
     * @return the a
     */
    public Workstation getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setMR(Workstation a, long b) {
        this.a = a;
        a.getA().getAlarm().setB(b);
    }

    public void stopMR(Workstation a) {
        a.getA().getAlarm().setB(0);
    }

    public void setAR(Workstation a, long b) {
        this.a = a;
        a.getB().getAlarm().setB(b);
    }

    public void stopAR(Workstation a) {
        this.a=a;
        a.getB().getAlarm().setB(0);
    }
    public WorkOP(String Uname, String Pword) {
        //pre-defined battery life
        long g = 10000, h = 15000;
        //new workstation
        a = new Workstation(g, h);
        this.Uname = Uname;
        this.Pword = Pword;
        this.id = id;
    }

    /**
     * @return the Uname
     */
    public String getUname() {
        return Uname;
    }

    /**
     * @param Uname the Uname to set
     */
    public void setUname(String Uname) {
        this.Uname = Uname;
    }

    /**
     * @return the Pword
     */
    public String getPword() {
        return Pword;
    }

    /**
     * @param Pword the Pword to set
     */
    public void setPword(String Pword) {
        this.Pword = Pword;
    }
}
