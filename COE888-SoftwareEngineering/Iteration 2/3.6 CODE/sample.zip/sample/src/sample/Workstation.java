/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author matheesan
 */
public class Workstation {
    private MovingRobot ar1;
    private AssemblyRobot mr1;
    /**
     * @return the a
     */
    public MovingRobot getA() {
        return ar1;
    }

    /**
     * @param a the a to set
     */
    public void setA(long a,MovingRobot ar1) {
        this.ar1=ar1;
        ar1.getAlarm().setB(a);
    }

    /**
     * @return the b
     */
    public AssemblyRobot getB() {
        return mr1;
    }

    /**
     * @param b the b to set
     */
    public void setB(long a,AssemblyRobot mr1) {
        this.mr1=mr1;
        mr1.getAlarm().setB(a);
    }
public Boolean getNotificationAR1(){
 boolean check=false;
 if(ar1.getNotification()==true)
     check =true;
 return check;
}
public Boolean getNotificationMR1(){
 boolean check=false;
 if(mr1.getNotification()==true)
     check =true;
 return check;
}
    Workstation (long alarm1, long alarm2){
        ar1 = new MovingRobot(alarm1);
        mr1 = new AssemblyRobot(alarm2);
    }
}
