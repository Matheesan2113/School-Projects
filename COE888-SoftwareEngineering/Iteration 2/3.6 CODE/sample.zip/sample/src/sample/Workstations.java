/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author matheesan
 */
@Entity
@Table(name = "WORKSTATIONS")
@NamedQueries({
    @NamedQuery(name = "Workstations.findAll", query = "SELECT w FROM Workstations w")
    , @NamedQuery(name = "Workstations.findById", query = "SELECT w FROM Workstations w WHERE w.id = :id")})
public class Workstations implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Lob
    @Column(name = "ALARM1")
    private String alarm1;
    @Lob
    @Column(name = "ALARM2")
    private String alarm2;
    @OneToMany(mappedBy = "workstation")
    private Collection<Loginwop> loginwopCollection;

    public Workstations() {
    }

    public Workstations(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlarm1() {
        return alarm1;
    }

    public void setAlarm1(String alarm1) {
        this.alarm1 = alarm1;
    }

    public String getAlarm2() {
        return alarm2;
    }

    public void setAlarm2(String alarm2) {
        this.alarm2 = alarm2;
    }

    public Collection<Loginwop> getLoginwopCollection() {
        return loginwopCollection;
    }

    public void setLoginwopCollection(Collection<Loginwop> loginwopCollection) {
        this.loginwopCollection = loginwopCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Workstations)) {
            return false;
        }
        Workstations other = (Workstations) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "sample.Workstations[ id=" + id + " ]";
    }
    
}
