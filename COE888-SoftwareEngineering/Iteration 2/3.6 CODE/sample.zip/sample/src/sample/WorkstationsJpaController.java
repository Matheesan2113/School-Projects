/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import sample.exceptions.NonexistentEntityException;

/**
 *
 * @author matheesan
 */
public class WorkstationsJpaController implements Serializable {

    public WorkstationsJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Workstations workstations) {
        if (workstations.getLoginwopCollection() == null) {
            workstations.setLoginwopCollection(new ArrayList<Loginwop>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Loginwop> attachedLoginwopCollection = new ArrayList<Loginwop>();
            for (Loginwop loginwopCollectionLoginwopToAttach : workstations.getLoginwopCollection()) {
                loginwopCollectionLoginwopToAttach = em.getReference(loginwopCollectionLoginwopToAttach.getClass(), loginwopCollectionLoginwopToAttach.getId());
                attachedLoginwopCollection.add(loginwopCollectionLoginwopToAttach);
            }
            workstations.setLoginwopCollection(attachedLoginwopCollection);
            em.persist(workstations);
            for (Loginwop loginwopCollectionLoginwop : workstations.getLoginwopCollection()) {
                Workstations oldWorkstationOfLoginwopCollectionLoginwop = loginwopCollectionLoginwop.getWorkstation();
                loginwopCollectionLoginwop.setWorkstation(workstations);
                loginwopCollectionLoginwop = em.merge(loginwopCollectionLoginwop);
                if (oldWorkstationOfLoginwopCollectionLoginwop != null) {
                    oldWorkstationOfLoginwopCollectionLoginwop.getLoginwopCollection().remove(loginwopCollectionLoginwop);
                    oldWorkstationOfLoginwopCollectionLoginwop = em.merge(oldWorkstationOfLoginwopCollectionLoginwop);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Workstations workstations) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Workstations persistentWorkstations = em.find(Workstations.class, workstations.getId());
            Collection<Loginwop> loginwopCollectionOld = persistentWorkstations.getLoginwopCollection();
            Collection<Loginwop> loginwopCollectionNew = workstations.getLoginwopCollection();
            Collection<Loginwop> attachedLoginwopCollectionNew = new ArrayList<Loginwop>();
            for (Loginwop loginwopCollectionNewLoginwopToAttach : loginwopCollectionNew) {
                loginwopCollectionNewLoginwopToAttach = em.getReference(loginwopCollectionNewLoginwopToAttach.getClass(), loginwopCollectionNewLoginwopToAttach.getId());
                attachedLoginwopCollectionNew.add(loginwopCollectionNewLoginwopToAttach);
            }
            loginwopCollectionNew = attachedLoginwopCollectionNew;
            workstations.setLoginwopCollection(loginwopCollectionNew);
            workstations = em.merge(workstations);
            for (Loginwop loginwopCollectionOldLoginwop : loginwopCollectionOld) {
                if (!loginwopCollectionNew.contains(loginwopCollectionOldLoginwop)) {
                    loginwopCollectionOldLoginwop.setWorkstation(null);
                    loginwopCollectionOldLoginwop = em.merge(loginwopCollectionOldLoginwop);
                }
            }
            for (Loginwop loginwopCollectionNewLoginwop : loginwopCollectionNew) {
                if (!loginwopCollectionOld.contains(loginwopCollectionNewLoginwop)) {
                    Workstations oldWorkstationOfLoginwopCollectionNewLoginwop = loginwopCollectionNewLoginwop.getWorkstation();
                    loginwopCollectionNewLoginwop.setWorkstation(workstations);
                    loginwopCollectionNewLoginwop = em.merge(loginwopCollectionNewLoginwop);
                    if (oldWorkstationOfLoginwopCollectionNewLoginwop != null && !oldWorkstationOfLoginwopCollectionNewLoginwop.equals(workstations)) {
                        oldWorkstationOfLoginwopCollectionNewLoginwop.getLoginwopCollection().remove(loginwopCollectionNewLoginwop);
                        oldWorkstationOfLoginwopCollectionNewLoginwop = em.merge(oldWorkstationOfLoginwopCollectionNewLoginwop);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = workstations.getId();
                if (findWorkstations(id) == null) {
                    throw new NonexistentEntityException("The workstations with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Workstations workstations;
            try {
                workstations = em.getReference(Workstations.class, id);
                workstations.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The workstations with id " + id + " no longer exists.", enfe);
            }
            Collection<Loginwop> loginwopCollection = workstations.getLoginwopCollection();
            for (Loginwop loginwopCollectionLoginwop : loginwopCollection) {
                loginwopCollectionLoginwop.setWorkstation(null);
                loginwopCollectionLoginwop = em.merge(loginwopCollectionLoginwop);
            }
            em.remove(workstations);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Workstations> findWorkstationsEntities() {
        return findWorkstationsEntities(true, -1, -1);
    }

    public List<Workstations> findWorkstationsEntities(int maxResults, int firstResult) {
        return findWorkstationsEntities(false, maxResults, firstResult);
    }

    private List<Workstations> findWorkstationsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Workstations.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Workstations findWorkstations(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Workstations.class, id);
        } finally {
            em.close();
        }
    }

    public int getWorkstationsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Workstations> rt = cq.from(Workstations.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
