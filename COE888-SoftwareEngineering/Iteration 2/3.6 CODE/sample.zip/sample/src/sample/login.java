/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.ArrayList;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author matheesan
 */
public class login {
    private int a;
    private ArrayList<ProcessEngineer> peArray = new ArrayList<ProcessEngineer>();
    private ArrayList<ProductManager> pmArray = new ArrayList<ProductManager>();
    private ArrayList<WorkOP> workopArray = new ArrayList<WorkOP>();
    
public void checkarrays(){
    System.out.println(peArray);
    System.out.println(pmArray);
    System.out.println(workopArray);
    for(ProcessEngineer item : peArray){
	System.out.println(item);
        if(item.getUname().equalsIgnoreCase("comp"))
            System.out.println("YES");
    }
}
public WorkOP findwop(String username){
    WorkOP po = null;
    for(WorkOP user : workopArray){
        if(user.getUname().equalsIgnoreCase(username))
            po=user;
    }
    return po;
}
public ProcessEngineer findEngineer(String username){
    ProcessEngineer po = null;
    for(ProcessEngineer user : peArray){
        if(user.getUname().equalsIgnoreCase(username))
            po=user;
    }
    return po;
}
public ProductManager findManager(String username){
    ProductManager po = null;
    for(ProductManager user : pmArray){
        if(user.getUname().equalsIgnoreCase(username))
            po=user;
    }
    return po;
}

    /**
     * @return the a
     */
    public int getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setA(int a) {
        this.a = a;
    }

    /**
     * @return the peArray
     */
    public ArrayList<ProcessEngineer> getPeArray() {
        return peArray;
    }

    /**
     * @param peArray the peArray to set
     */
    public void setPeArray(ArrayList<ProcessEngineer> peArray) {
        this.peArray = peArray;
    }

    /**
     * @return the pmArray
     */
    public ArrayList<ProductManager> getPmArray() {
        return pmArray;
    }

    /**
     * @param pmArray the pmArray to set
     */
    public void setPmArray(ArrayList<ProductManager> pmArray) {
        this.pmArray = pmArray;
    }

    /**
     * @return the workopArray
     */
    public ArrayList<WorkOP> getWorkopArray() {
        return workopArray;
    }

    /**
     * @param workopArray the workopArray to set
     */
    public void setWorkopArray(ArrayList<WorkOP> workopArray) {
        this.workopArray = workopArray;
    }
    
}
